package com.waylau.spring.cloud.weather.microweathereurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroWeatherEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroWeatherEurekaServerApplication.class, args);
	}
}
